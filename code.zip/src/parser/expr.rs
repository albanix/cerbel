use crate::tokens::Token;
/// The Expr enum will store itself recursively, to represent operator precedence.
#[derive(Debug, Clone)]
pub enum Expr {
    Number(f64),
    BinaryOp {
        left: Box<Expr>,
        op: Token,
        right: Box<Expr>
    }
}

pub fn eval(expr: &Expr) -> f64 {
    match expr {
        Expr::Number(n) => *n,
        Expr::BinaryOp { left, op, right } => {
            let l = eval(left);
            let r = eval(right);
            match op {
                Token::Plus => l + r,
                Token::Minus => l - r,
                Token::Star => l * r,
                Token::Slash => l / r,
                _ => panic!("Unknown operator {:?}", op)
            }
        }
    }
}