use crate::{parser::expr::Expr, tokens::Token};
pub mod expr;

/// The parser is the component that builds the AST. It stores the current token (recall the lexer) and an index/pointer into the token stream. The parser defines operator precedence, among other things.
pub struct Parser {
    tokens: Vec<Token>,
    pos: usize
}

impl Parser {
    pub fn new(tokens: Vec<Token>) -> Self {
        Self {
            tokens,
            pos: 0
        }
    }

    pub fn current_token(&self) -> &Token {
        &self.tokens[self.pos]
    }

    pub fn advance(&mut self) -> Token {
        let tok = self.tokens[self.pos].clone();
        self.pos += 1;
        tok
    }

    pub fn parse_expr(&mut self) -> Expr {
        let mut left = self.parse_term();

        while matches!(self.current_token(), Token::Plus | Token::Minus) {
            let op = self.advance();
            let right = self.parse_term();
            left = Expr::BinaryOp { 
                left: Box::new(left),
                op,
                right: Box::new(right)
            };
        }

        left
    }

    pub fn parse_term(&mut self) -> Expr {
        let mut left = self.parse_factor();

        while matches!(self.current_token(), Token::Star | Token::Slash) {
            let op = self.advance();
            let right = self.parse_factor();
            left = Expr::BinaryOp { 
                left: Box::new(left), 
                op, 
                right: Box::new(right)
            };
        }

        left
    }
    pub fn parse_factor(&mut self) -> Expr {
        match self.advance() {
            Token::Number(n) => Expr::Number(n),
            Token::LParen => {
                let expr = self.parse_expr();
                self.advance();
                expr
            }
            other => panic!("Unexpected token: {:?}", other),
        }
    }
}