pub mod lexer;
pub mod tokens;
pub mod parser;

use crate::lexer::Lexer;
use crate::parser::{Parser, expr};
fn main() {
    // Заправляем лексер токенами
    let mut lexer = Lexer::new("35*79");
    
    // Получаем все токены примерно [Number(2), Plus, LParen, Number(2), Star, Number(2), RParen]
    let token = lexer.tokenize();
     
    println!("{:?}", token);
    // инитим парсер
    let mut parser = Parser::new(token);
    // строим аст
    let ast = parser.parse_expr();

    println!("Еval({})", expr::eval(&ast));
}