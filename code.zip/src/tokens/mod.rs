/// Enum of tokens
#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    Number(f64),
    Star,
    Slash,
    Plus,
    Minus,
    RParen,
    LParen,
    Eof
}